/**
 * Theme: Robotech - Tailwind Admin Dashboard Template
 * Author: Mannatthemes
 * Clipboard Js
 */




var clipboard = new ClipboardJS('.copy_cut');