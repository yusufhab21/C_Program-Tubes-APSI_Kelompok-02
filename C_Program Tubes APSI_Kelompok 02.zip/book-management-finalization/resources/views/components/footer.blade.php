<!-- footer -->
<div class="absolute bottom-0 -left-4 -right-4 block print:hidden border-t p-4 h-[52px] dark:border-slate-700/40">
    <div class="container">
        <!-- Footer Start -->
        <footer class="footer bg-transparent  text-center  font-medium text-slate-600 dark:text-slate-400 md:text-left ">
            &copy;
            <script>
                var year = new Date();
                document.write(year.getFullYear());
            </script>
            Book Management

        </footer>
        <!-- end Footer -->
    </div>
</div>
